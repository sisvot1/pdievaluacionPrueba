<?php
	echo $AppUI->getMsg();
?>
	</td>
</tr>
</table>
</body>
</html>