<?php /* STYLE/CLASSIC $Id: overrides.php 1699 2003-12-04 21:48:39Z jcgonz $ */
##
##	This may override the show function of the CTabBox_core function
## Just use the vanilla version for the default case
##
class CTabBox extends CTabBox_core {

}

class CTitleBlock extends CTitleBlock_core {
}
?>