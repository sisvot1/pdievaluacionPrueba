<?php
if (!defined('DP_BASE_DIR')) {
	die('You cannot run this file directly');
}

class mysqlAuthenticator extends SQLAuthenticator
{
	function __construct()
	{
	}

	function authenticate($username, $password)
	{
	}
}
