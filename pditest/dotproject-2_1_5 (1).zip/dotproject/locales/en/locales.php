<?php
//$locale_char_set = 'iso-8859-1';
$locale_char_set = 'utf-8';
// 0 = sunday, 1 = monday
define('LOCALE_FIRST_DAY', 0);
define('LOCALE_TIME_FORMAT', '%I:%M %p');
?>
